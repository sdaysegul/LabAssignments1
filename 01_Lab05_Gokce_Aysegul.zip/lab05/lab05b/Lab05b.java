import java.util.Scanner;

/**
 * __Lab05b__ 
 * @author __Aysegul Gokce___
 * @version __30.10.2017__
 */ 
public class Lab05b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int row;
      int cloumns;
      int x;
      int y;
      int a;
      int b;

      // program code
      System.out.println(" Please give a number for row.");
         row = scan.nextInt();
      System.out.println(" Please give a number for cloumns.");
         cloumns = scan.nextInt();
         //1
      for (x=1; x <= row; x++){
        for ( y=1; y <= cloumns; y++){
         for (b = (Integer.toString(x) + Integer.toString(y)).length(); b <= 5; b++){
         System.out.print(" ");
         }
         System.out.print( x + "," + y );
        }
      System.out.println("");
      }
      System.out.println("\n");
      //2
      for (x=1; x <= row; x++){
        for ( y=1; y <= cloumns; y++){
         for (b = Integer.toString(x * y).length(); b <= 6; b++){
         System.out.print(" ");
         }
         System.out.print( x * y );
        }
      System.out.println("");
      }
      System.out.println("\n");
      //3
      a=0;
      for (x=0; x < row; x++){
         for ( y=0; y < cloumns; y++){
         for (b = Integer.toString(a).length(); b <= 6; b++){
         System.out.print(" ");
         }
         System.out.print( a );
         a++;
         }
      System.out.println("");
      }
      System.out.println("\n");
      //4
      for (x=0; x < row; x++){
         for ( y=0; y < cloumns; y++){
           if ( y == 0){
               for (b = Integer.toString(x+1).length(); b <= 6; b++){
               System.out.print(" ");
               }
               System.out.print(x+1);
           }
           else{
              System.out.print("     ");
               System.out.print( "-");
           }
         }
      System.out.println("");
      }
   }

}