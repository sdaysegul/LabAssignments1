import java.util.Scanner;

/**
 * __Lab05c___ 
 * @author __Ay�eg�l G�k�e___
 * @version __30.10.2017__
 */ 
public class Lab05c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      String request;
      double sinResult;
      double result;
      double number;
      int n;
      double factorial;
      result = 0;
      number = 0;
      

      // program code
      System.out.println( "Welcome to my calculator!");
      do{
         System.out.println( result );
         System.out.println(" There are the options you have;" );
         System.out.println(" +,-,*,/,sin value" + "\n" + " Clear " + "\n" + " Quit " );
         request = scan.nextLine();
         if ( request.charAt(0) == '+'){
            number = Double.parseDouble(request.substring(2));
            result = number + result;
      }
         if ( request.charAt(0) == '-'){
            number = Double.parseDouble(request.substring(2));
            result = result - number;
      }
         if ( request.charAt(0) == '*'){
            number = Double.parseDouble(request.substring(2));
            result = number * result;
      }
         if ( request.charAt(0) == '/'){
            number = Double.parseDouble(request.substring(2));
            result = result / number;
      }
         if ( request.equals( "sin") ){
            //number = Double.parseDouble(request.substring(4));
            sinResult = Math.sin(result*(Math.PI/180));
            System.out.println (sinResult);
            //to find sin using taylor
            double subsum = 0;
           for ( n = 0; n < 15 ; n++){
            //to find factorial
            factorial = 1;
            int fa = 1;
            while ( fa <= 2*n +1 ){
              factorial = factorial * fa;
            fa++;
           }
            subsum = (Math.pow(-1,n) * Math.pow( result, 2*n+1 ) / factorial) + subsum;
            }
           result = subsum;
         }
         if ( request.charAt(0) == 'c' || request.charAt(0) == 'C'){
            result = 0;
      }
      }while( request.charAt(0) != 'Q' && request.charAt(0) != 'q');
      
      System.out.println( "End.");
   }

}