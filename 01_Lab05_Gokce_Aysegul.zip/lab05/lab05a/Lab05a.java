import java.util.Scanner;

/**
 * __YILDIZ__ 
 * @author __Aysegul Gokce___
 * @version __30.10.2017__
 */ 
public class Lab05a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      String answer;
      int width;
      int height;
      int thickness;
      int a;
      int b;

      // program code
      do {
      System.out.println( "Please first enter the width of pattern you want.");
      width = scan.nextInt();
      System.out.println( "Now, enter height for it.");
      height = scan.nextInt();
      System.out.println( "Last, thickness!");
      thickness = scan.nextInt();
      if ( width > 0 && height > 0 && thickness > 0){
         for ( a = 0; a < height; a++){
            if ( a < thickness || a >= height - thickness){
               for ( b=0; b < width; b++)
               System.out.print("*");
            }
            else
               for ( b=0; b < width; b++){
               if (b < thickness || b >= width - thickness)
                  System.out.print("*");
               else 
                  System.out.print(" ");
            }
            System.out.println("");
         }
         if ( width == 2 * thickness || height == 2 * thickness){
         System.out.println(" Opps, there is no hole!");
         }
         
         System.out.println(" Do you wanna create another one?");
         answer = scan.next();
      }else
         answer = "";
         System.out.println(" Sorry, all values must be positive!");
      } while ( answer.equals("y") || answer.equals( "Y") ); 

   }

}