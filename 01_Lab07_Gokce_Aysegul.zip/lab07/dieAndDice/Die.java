/**
 * __Lab07a - Die___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class Die
{
   // properties
   private int faceValue;
   
   // constructors
   
   /**
   * Constructs the rolling of a die.
   */
   
   public Die()
   {
      roll();
   }
 
   // methods
   
  /**
   * A method to get random values between 1-6.
   * @return state - The return of the faceValue.
   */
   
   public int roll()
   {
      faceValue = (int)(Math.random() * 6) + 1;
      return faceValue;
   }
   
  /**
   * A method to get the face value of the dice.
   * @return face - Returns the face value.
   */
   
   public int getFaceValue()
   {
      return faceValue;
   }
   
  /**
   * A method to turn the output into a string.
   * @return Returns the string that the programmer has typed down.
   */
   
   public String toString()
   {
      return "die shows " + faceValue + ".";
   }
}

