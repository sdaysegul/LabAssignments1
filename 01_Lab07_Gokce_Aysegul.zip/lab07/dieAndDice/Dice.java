/**
 * __Lab07a - Dice___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class Dice
{
   // properties
   private Die die1;
   private Die die2;
   
   // constructors
   
  /**
   * Constructs the rolling of a dice.
   */
   
   public Dice()
   {
      die1 = new Die();
      die2 = new Die();    
   }
   // methods
 
  /**
   * A roll method that get random values between 1-6.
   * @return Returns the sum of the faces of the dice
   */
   
   public int roll()
   {
      return die1.roll() + die2.roll();
   }
   
  /**
   * A method to get the facValue of die1.
   * @return Returns the faceValue of die1.
   */
   
   public int getDie1FaceValue()
   {
      return die1.getFaceValue();
   }
   
  /**
   * A method to get the faceValue of die2.
   * @return Returns the faceValue of die2.
   */
   
   public int getDie2FaceValue()
   {
      return die2.getFaceValue();
   }
   
  /**
   * A method to sum the face values of the dice up.
   * @return Returns the SUM of the face values of the dice.
   */
   
   public int getDiceTotal()
   {
      return getDie1FaceValue() + getDie2FaceValue();
   }
   
  /**
   * A method to turn the output into a string.
   * @return Returns the string that the programmer has typed down.
   */
   
   public String toString()
   {
      return getDie1FaceValue() + "AND " + getDie2FaceValue();
   }
}

