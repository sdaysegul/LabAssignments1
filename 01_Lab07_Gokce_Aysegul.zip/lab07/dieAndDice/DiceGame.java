/**
 * __Lab07a - Dice Game___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 
/**
 * A simple Java class!
 */
public class DiceGame 
{
   // properties
   Dice dice;
   
   // constructors
   public DiceGame(){
     dice = new Dice();
   }
   
   // methods
   public void play() {
     int roll = 0; 
     do{
         dice.roll();
         roll ++;
      } while (dice.getDiceTotal() != 12);
      
      System.out.print("roll number is" + roll );
   }
}

