/**
 * __Lab07a - Dice Test___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class DiceTest
{
   public static void main( String[] args)
   {
      Dice d1;
      d1 = new Dice(); 
      d1.roll();
      System.out.println(d1);
      System.out.println("dice show " + 
                         d1.getDie1FaceValue() + " and " + 
                         d1.getDie2FaceValue() + ".");
   }
}

