/**
 * __Lab07a - Test Die___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class TestDie
{
   public static void main( String[] args)
   {
      Die die1;
      Die die2;
      die1 = new Die(); 
      die2 = new Die();
      die1.roll();
      die2.roll();
      System.out.println("dice are " + 
                         die1.getFaceValue() + " and " + 
                         die2.getFaceValue() + ".");
      die1.roll();
      die2.roll();
      System.out.println(die1);
      System.out.println(die2);
   }
}

