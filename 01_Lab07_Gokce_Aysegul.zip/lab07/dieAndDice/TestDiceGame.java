/**
 * __Lab07a - Test Dice Game___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class TestDiceGame
{
   public static void main( String[] args)
   {
      DiceGame diceGame;
      diceGame = new DiceGame();
      diceGame.play();
      
   }
}
