import java.util.Scanner;

/**
 * __Die&Dice___ 
 * @author __Ay�eg�l G�k�e__
 * @version __27/10/2017__
 */ 
public class DieAndDice
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int die1;
      int die2;
      int roll;

      // program code
      roll = 0;
      do{
         die1 =(int)(6 * Math.random()) + 1;
         die2 =(int)(6 * Math.random()) + 1;
         roll ++;
      } while (die1 != 6 || die2 != 6);
      
      System.out.print(roll );
         
   }

}

