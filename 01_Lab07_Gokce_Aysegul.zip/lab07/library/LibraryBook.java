/**
 * __Lab07b - Library Book___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class LibraryBook
{
   // properties
   private String title;
   private String author;
   private String dueDate;
   private int timesLoaned;
   
   // constructors
   
   /**
    * Constructs a library book that has the titles, authors, due dates of the 
    * books and the times they were loaned.
    */
   
   public LibraryBook(String theTitle, String theAuthor)
   {
     title = theTitle;
     author = theAuthor;
     dueDate = "";
     timesLoaned = 0;    
   }
   
   // methods
   
   /**
    * A method to loan a book.
    * @param date - The date
    */
   
   public void loanBook(String date)
   {
      dueDate = date;
      timesLoaned = timesLoaned + 1;   
   }
   
   /**
    * A method to return a book.
    */
   
   public void returnBook()
   {
      dueDate = "";
   }
   
   /**
    * A method that returns loan times.
    * @return timesLoaned - Returns loan times.
    */
   
   public int getTimesLoaned()
   {
      return timesLoaned;
   }
   
   /**
    * A method to check if the book is on loan.
    * @return Returns true or false.
    */
   
   public boolean onLoan()
   {
     boolean result;
     result = !dueDate.equals("");
      return result;
   }
   
   /**
    * A method to turn the output into a string.
    * @return Returns the string that the programmer has typed down.
    */
   
   public String toString()
   {
      return title + ", " + author + ", " + dueDate + ", " +  timesLoaned;
   }
   
   /**
    * A method to get the title.
    * @return title - Returns the title.
    */
   
   public String getTitle()
   {
      return title;
   }
}
