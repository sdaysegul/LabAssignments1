/**
 * __Lab07b - Test Library Book___ 
 * @author __Ay�eg�l G�k�e___
 * @version __27.11.2016__
 */ 

public class TestLibraryBook
{
   public static void main( String[] args)
   {
      LibraryBook book1;
      LibraryBook book2;
      LibraryBook book3;
      book1 = new LibraryBook("Ay�eg�l A�l�yor", "Gilbert Delaheye");
      book2 = new LibraryBook("Ay�eg�l Kafay� Yemek �zere", "Gilbert Delaheye");
      book3 = new LibraryBook("Yeteer!", "Gilbert Delaheye");
      System.out.println(book1);
      System.out.println(book2);
      System.out.println(book3);
      
      book1.loanBook("29.01.2018");
      if (book1.onLoan())
      {
         System.out.println(book1.getTitle() + " is on loan.");
      }
      
      book1.returnBook();
      book1.loanBook("30.03.1998");
      book1.returnBook();
      book1.loanBook("22.01.2003");
      book1.returnBook();
      book1.loanBook("20.12.2016");
      System.out.println("This book was loaned " + book1.getTimesLoaned() +
                         " times.");
      
         
         
         
   }
}

