import java.util.Scanner;

/**
 * __program description___ 
 * @author __your name___
 * @version __date__
 */ 
public class Lab04c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int n1;
      int n2;
      int min;
      int max;
      int sum;
      int counter;
      double average;

      // program code
      n1 = scan.nextInt();
        min = n1;
        max = n1;
        sum = n1;
        counter = 0;
      while ( n1 > 0) {
        n1 = scan.nextInt();
        if ( n1 > 0){
        sum = sum + n1;
        min = Math.min ( min, n1 );
        max = Math.max (max, n1 );
        counter++;
        }
      }
        if ( n1 < 0){
          average = (double) sum / (double) (counter + 1);
      System.out.print( "min is " + min + " max is " + max + " sum is " + sum + " average is " + average);
        }
     
   }
}
