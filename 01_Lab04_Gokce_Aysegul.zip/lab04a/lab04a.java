import java.util.Scanner;

/**
 * __program description___ 
 * @author __your name___
 * @version __date__
 */ 
public class lab04a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int n;
      int a;
      int c;
      // program code
      c = 0;
      a = 0;
      n = scan.nextInt();
      if ( n < 0)
        System.out.println( "Please enter a positive number!" );
        else{
          //1
          while ( n > a ){
        System.out.print( a + " ");
        a++;
          }
     //2
        System.out.println( "\n");
        a = 0;
          while ( n > a ){
        System.out.print( a + " ");
        a++;
          if (a % 5 == 0 && a != n )
            System.out.print( "\n");
          }
     //3
       System.out.println( "\n");
       a = n;
           while ( a >= 0){
        System.out.print( a + " ");
        a--;
          }
     //4
           System.out.println( "\n");
         a = -n;
         while ( a <= n){
           if ( a % 2 == 0)
             System.out.print( a + " ");
        a++;
          }
     //5
         System.out.println( "\n");
         a = 0;
          while ( n >= a ){
           if ( a % 2 == 0)
             System.out.print( (a * a) + " ");
        a++;
          if (a % 10 == 0)
            System.out.print( "\n");
          }
      //6              
           System.out.println( "\n");
         a = n;
         while ( a >= 3){
           if ( (a % 4 == 0 || a % 3 == 0) && a % 12 != 0){
             System.out.print( a + " ");
             c++;
             if (c % 5 == 0)
            System.out.print( "\n");
           }
        a--;
         }
       //7
           System.out.println( "\n");
         a = 2;
         c = 0;
         while ( n >= a){
           if ( n % a == 0 ){
             System.out.print( a + " ");
             c++;
             if (c % 5 == 0)
            System.out.print( "\n");
           }
        a++;          
         } 
       //8
         System.out.println( "\n");
         a = n;
         while ( a >= 1 ) {
           float k = 1 / (float)a;
             if ( k > 0.01 )
             System.out.printf("%.2f ",k );
           a--;          
         }
         
         
        }
   }
   
}