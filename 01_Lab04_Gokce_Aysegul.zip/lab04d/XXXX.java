import java.util.Scanner;

/**
 * __program description___ 
 * @author __your name___
 * @version __date__
 */ 
public class XXXX
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables

      // program code
      double d;
d = 0.1;
while ( d != 1.0 )
{
   System.out.println( d);
   d = d + 0.1;
}
System.out.println( d + " <- final value after loop!");
      System.out.println( "Start...");


      System.out.println( "End.");
   }

}