import java.util.Scanner;

/**
 * __program description___ 
 * @author __your name___
 * @version __date__
 */ 
public class Lab04d
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      char ch;
      int width, a = 0, b =0;

      // program code
     ch = scan.next().charAt(0);
      width = scan.nextInt();
      while (a < width){
        b = 0;
        while ( b <= a){
        System.out.print( ch + " ");
        b++;
        }
        System.out.println();
        a++;
      }
   }
   }
