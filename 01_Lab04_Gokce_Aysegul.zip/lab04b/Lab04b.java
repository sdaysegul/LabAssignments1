import java.util.Scanner;

/**
 * __program description___ 
 * @author __your name___
 * @version __date__
 */ 
public class Lab04b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      final int NUMBER = 10;

      // variables
      int a, sum = 0, counter = 0;

      // program code
      while (counter < NUMBER){
        a = scan.nextInt();
        sum = sum + a;
        counter++;
      }
      System.out.print( counter + " number entered and sum is " + sum); 
        
   }

}