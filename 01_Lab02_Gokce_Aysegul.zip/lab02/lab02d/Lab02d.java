import java.util.Scanner;

/**
 * __Lab02d___ 
 * @author __Aysegul Gokce___
 * @version __09.10.2017__
 */ 
public class Lab02d
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      final int FLOWER_TO_METER = 17;

      // variables
      double s, a, b, c ;
      double area;
      int flower;
      
      

      // program code
      System.out.println( "First edge: ");
      a = scan.nextDouble();
      System.out.println( "Second edge: ");
      b = scan.nextDouble();
      System.out.println( "Third edge: ");
      c = scan.nextDouble();
      
      
       //compute s
      
      s = (a + b + c) / 2;
      
      //calculate the area using heron's formula
      area = Math.sqrt( s * (s - a) * (s - b) * (s - c));
      
      //calculate the max flower number
      flower = (int)area * FLOWER_TO_METER;
      
      
       // Print
        System.out.println( "the number of max flower is " + flower );

   }

}