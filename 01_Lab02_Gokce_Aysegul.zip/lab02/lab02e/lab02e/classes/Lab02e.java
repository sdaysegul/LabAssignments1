import java.util.Scanner;

/**
 * __Lab02e___ 
 * @author __Aysegul Gokce___
 * @version __09.10.2017__
 */ 
public class Lab02e
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      Scanner scan2 = new Scanner( System.in);

      // constant;
      final String HTML_OPEN_TAG = "<html>";
      final String HEAD_OPEN_TAG = "<head>";
      final String TITLE_OPEN_TAG = "<title>";
      final String BODY_OPEN_TAG = "<body>";
      final String HTML_CLOSE_TAG = "</html>";
      final String HEAD_CLOSE_TAG = "</head>";
      final String TITLE_CLOSE_TAG = "</title>";
      final String BODY_CLOSE_TAG = "</body>";
      final String HR_OPEN_TAG = "<hr>";
      final String H1_OPEN_TAG = "<h1>";
      final String H1_CLOSE_TAG = "</h1>";
      final String P_OPEN_TAG = "<p>";
      final String P_CLOSE_TAG = "</p>";

      // variables
      String name;
      int age;
      double salary;
      String comment;
       
      // program code
      System.out.println( "Please enter your name : " );
      name = scan.nextLine ();
      System.out.println( "Please enter your age : ");
      age = scan.nextInt ();
      System.out.println( "Please enter your salary : ");
      salary = scan.nextDouble ();
      System.out.println( "Please enter your comment : ");
      comment = scan2.nextLine ();
 
      System.out.println( "<!DOCTYPE html>");
      System.out.println( HTML_OPEN_TAG + "/n");
      System.out.println( HEAD_OPEN_TAG);
      System.out.println( TITLE_OPEN_TAG + name + "'s Home Page" + TITLE_CLOSE_TAG );
      System.out.println( HEAD_CLOSE_TAG + "/n");
      System.out.println( BODY_OPEN_TAG + "/n" );
      System.out.println( HR_OPEN_TAG);
      System.out.println( H1_OPEN_TAG + name + H1_CLOSE_TAG );
      System.out.println( P_OPEN_TAG + "Age: " + age + P_CLOSE_TAG);
      System.out.println( P_OPEN_TAG + "Salary: " + salary + P_CLOSE_TAG);
      System.out.println( P_OPEN_TAG + "Comments: " + comment + P_CLOSE_TAG);
      System.out.println( HR_OPEN_TAG + "/n");
      System.out.println( BODY_CLOSE_TAG + "/n");
       System.out.println( HTML_CLOSE_TAG);
                         
   }

}