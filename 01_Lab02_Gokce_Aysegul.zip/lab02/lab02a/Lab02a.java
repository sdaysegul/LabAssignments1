import java.util.Scanner;

/**
 * __program description___ 
 * @author __Aysegul Gokce___
 * @version __09.10.2017__
 */ 
public class Lab02a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables

      // program code
      System.out.println( "Start...");


      System.out.println( "End.");
   }

}