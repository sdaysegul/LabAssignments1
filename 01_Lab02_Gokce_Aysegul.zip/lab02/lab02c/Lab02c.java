import java.util.Scanner;

/**
 * __lab02c___ 
 * @author __Aysegul Gokce___
 * @version __09.10.2017__
 */ 
public class Lab02c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int x, y;
      int sum;
      int difference;
      int product;
      int division;
      int remainder;
      int max;
      int min;

      // program code
      System.out.println( "Please enter the first integer." );
      x = scan.nextInt();
      System.out.println( "please enter yhe second integer." );
      y = scan.nextInt();
      
      //sum
      sum = x + y;
      
      //difference
      difference = x - y;
      
      //product
      product = x * y;
      
      //division
      division = x / y;
      
      //remainder
      remainder = x % y;
      
      //max and min
      max = Math.max(x, y);
      min = Math.min(x, y);
      
      
      //print
      
      System.out.println( "Sum is " + sum + " " );
      System.out.println( "Difference is " + difference + " " );    
      System.out.println( "Product is " + product + " " );
      
      System.out.println( "Division is " + division + " " );
      
      System.out.println( "Remainder is " + remainder + " " );
      
      System.out.println( "Max one is " + max + " " );
      
      System.out.println( "Min one is " + min + " " );
      
     
   }

}