import java.util.Scanner;

/**
 * __lab03a___ 
 * @author __Aysegul Gokce___
 * @version __14.10.2017__
 */ 
public class Lab03a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      int e, o, n, sum;

      // program code
      o = 0;
      e = 0;
      sum = 0;
      
      System.out.println("Please enter a n number for sum.");
      n = scan.nextInt();
      
      for ( int x = 0; x <= 50; x++ ) 
      {
        if ( x <= n )
          sum = sum + x;
        if (x < 12 || x > 25)
          System.out.println( x + " is out of range 12-25");
        if ( x % 2 ==0)
          e = e + 1;
        else 
          o = o + 1;
        if (x % 5 == 0)
          System.out.println(" Hi five!");
        else if (x % 2 == 0)
          System.out.println(" Hi two!");
        else if (x % 7 == 0 || x % 3 == 0)
          System.out.println(" Hi sevenorthree!");
        else 
          System.out.println(" Hi others!");
      }

System.out.println("\n" + e + " even number, " + o + " odd number there.");

if ( sum == (n * (n+1) / 2))
   System.out.println("\n" + "they are same" );
else
   System.out.println( "\n" + "they are not same");

   }
}