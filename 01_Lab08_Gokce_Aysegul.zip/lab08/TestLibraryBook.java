import java.util.Scanner;
/**
 * __Lab07b - Test Library Book___ 
 * @author __Ay�eg�l G�k�e___
 * @version __04.12.2017__
 */ 

public class TestLibraryBook
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      //variables
      LibraryBook book1;
      LibraryBook book2;
      LibraryBook book3;
      LibraryBook book1Clone;
      //program code
      book1 = new LibraryBook("Book", "Auther");
      book2 = book1;
      book3 = new LibraryBook("anotherBook", "DifferentAuther");
      book1Clone = new LibraryBook( book1);
      System.out.println(book1);
      System.out.println(book2);
      System.out.println(book3);
      
      System.out.println("-------------------------------------");      
      if ( book1 == book2 ) {
         System.out.println(" book1 and book2 are the same" );
      }
      else if ( book1.equals( book2) ){
            System.out.println(" book1 and book2 are not same but have the same proporties" );
      }
      else
         System.out.println(" book1 and book2 are totally different books" );
      
      System.out.println("-------------------------------------");      
      if ( book1 == book3 ) {
         System.out.println(" book1 and book3 are the same" );
      }
      else if ( book1.equals( book3) ){
            System.out.println(" book1 and book3 are not same but have the same proporties" );
      }
      else
         System.out.println(" book1 and book3 are totally different books" );
      
      System.out.println("-------------------------------------");      
      if ( book1 == book1Clone ) {
         System.out.println(" book1 and book1Clone are the same" );
      }
      else if ( book1.equals( book1Clone) ){
            System.out.println(" book1 and book1Clone are not same but have the same proporties" );
      }
      else
         System.out.println(" book1 and book1Clone are totally different books" );
            
      System.out.println("-------------------------------------");     
      
      System.out.println("book1 and book1clone has same title - " + book1.hasSameTitle(book1Clone));
      System.out.println("book1 and book1clone has same author - " + book1.hasSameAuthor(book1Clone));
      System.out.println("book1 and book1clone has same properties - " + book1.equals(book1Clone));
      System.out.println("book1 and book1clone always same - " + (book1 == book1Clone));
      
      System.out.println("-------------------------------------");     

   }
}