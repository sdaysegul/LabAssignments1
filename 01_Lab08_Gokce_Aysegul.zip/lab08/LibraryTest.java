import java.util.Scanner;
/**
 * __Lab07b - Test Library ___ 
 * @author __Ay�eg�l G�k�e___
 * @version __04.11.2017__
 */ 

public class LibraryTest
{
  public static void main( String[] args)
  {
    Scanner scan = new Scanner( System.in);
    //variables
    Library MyLibrary = new Library();
    String title;
    String author;
    String option = "";
    String option2 = "";
    String date;
    //program code
    do {
      System.out.println( " Please select what you want to do; \n -Show \n -Find \n -Add \n -Exit");
      option = scan.nextLine();
      if (option.toLowerCase().equals("show") ){
        System.out.println(MyLibrary);
        /*if ( MyLibrary.b1 != null ){
         System.out.println( Library.b1.toString());
         }
         if ( MyLibrary.b2 != null ){
         System.out.println( Library.b2.toString());
         }
         if ( MyLibrary.b3 != null ){
         System.out.println( Library.b3.toString());
         }
         if ( MyLibrary.b4 != null ){
         System.out.println( Library.b4.toString());
         } 
         System.out.println("That's all \n"); */
      }  
      if (option.toLowerCase().equals("find") ){
        title = scan.nextLine();
        if (MyLibrary.findByTitle(title)== null)
          System.out.println("Sorry, cannot find!");
        else {
          System.out.println(MyLibrary.findByTitle(title)); 
          System.out.println("\n Select what you want to do to this book; \n -remove\n -loan\n -return \n -back"); 
          option2 = scan.nextLine();
          if (option2.toLowerCase().equals("remove") ){
            MyLibrary.remove(MyLibrary.findByTitle(title));
          }
          if (option2.toLowerCase().equals("loan") ){
            date = scan.nextLine();
            MyLibrary.findByTitle(title).loanBook(date);
             }
          if (option2.toLowerCase().equals("return") ){
            MyLibrary.findByTitle(title).returnBook();
          }
        }
      }  
      if (option.toLowerCase().equals("add") ){
        System.out.println("Please enter the book name");
        title = scan.nextLine();
        System.out.println("Please enter the author name");
        author = scan.nextLine();
        MyLibrary.add(title , author);
        
      }  
      System.out.println("---------------------------------");
    } while (!option.toLowerCase().equals("exit"));
    
  }
}
