/**
 * A simple Java class!
 */
public class Library
{
   // properties
   static LibraryBook b1;
   static LibraryBook b2;
   static LibraryBook b3;
   static LibraryBook b4;

   // constructors
   /**
    * Constructs a library to an empty one
    */
   
   public Library()
   {
     b1 = null;
     b2 = null;
     b3 = null;
     b4 = null;    
   }
   
   
   // methods
   /**
    * A method to check if library is empty 
    */
   
   public boolean isEmpty()
   {
      return (b1 == null &&  b2 == null && b3 == null && b4 == null);
   }
   
   // methods
   /**
    * A method to return a string 
    */
   
   public String toString()
   {
      if (b1 == null && b2 == null && b3 == null && b4 == null){
         return "It is empty";      
      }
      else
         return b1 + "\n" + b2 + "\n" + b3 + "\n" + b4;
   }

   // methods
   /**
    * A method to return a string 
    */
   
   public void add(String title, String author)
   { 
      if ( b1 == null) {
         b1 = new LibraryBook ( title, author);
      }
      else if ( b2 == null) {
         b2 = new LibraryBook ( title, author);
      }
      else if ( b3 == null) {
         b3 = new LibraryBook ( title, author);
      }
      else if ( b4 == null) {
         b4 = new LibraryBook ( title, author);
      }
      else return;
   }
   
   
   // methods
   /**
    * A method to return a string 
    */
   
   public void remove(LibraryBook book)
   { 
      if (  b1 != null && book.equals(b1) ){
        b1 = null;
      } else if (  b2 != null && book.equals(b2)) {
         b2 = null;
      } else if (  b3 != null && book.equals(b3)) {
         b3 = null;
      } else if (  b4 != null && book.equals(b4)) {
         b4 = null;
      } else 
         System.out.println("error" );
   }
   
   public LibraryBook findByTitle( String title ){
      
      if ( b1 != null && title.equals(b1.getTitle()) ) {
         return b1;
      } else if (  b2 != null &&title.equals(b2.getTitle()) ) {
         return b2;
      } else if (  b3 != null &&title.equals(b3.getTitle()) ) {
         return b3;
      } else if (  b4 != null &&title.equals(b4.getTitle()) ) {
         return b4;
      } else 
         return null;
                 }
   
}