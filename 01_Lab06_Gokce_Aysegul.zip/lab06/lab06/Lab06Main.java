import java.util.Scanner;

/**
 * __Methods Practise___ 
 * @author __Ay�eg�l G�k�e___
 * @version __06.10.2017__
 */ 
public class Lab06Main
{
  /**
   * This is a brief description of the method.
   * @param x an example input parameter
   * @param y another example input 
   * @return some useful result
   */
  public static double power(double x, int y){
    
    double z = 1;
    while( y > 0){
      z = x * z;
      y--;
    }
    return z;
  }
  
  /**
   * This is a brief description of the method.
   * @param n an example input parameter
   * @return some useful result
   */
  public static int factorial(int n){
    int z = 1;
    while( n > 0){
      z = n * z;
      n--;
    }
    return z;
  }
  
  /**
   * This is a brief description of the method.
   * @param s an example input parameter
   * @return some useful result
   */
  public static String reverse( String s){
    String newS = "";
    for ( int a = s.length(); a > 0; a--){
      newS = newS + s.charAt(a-1);
    }
    return newS;
  }
  
  /**
   * This is a brief description of the method.
   * @param base2 an example input parameter
   * @return some useful result
   */
  public static int toDecimal( String base2){
    int z = 0;
    for(int a = 0; a < base2.length() ; a++){
      z = 2*z + base2.charAt(a) - '0' ;
    }
    return z;
  }
  
  /**
   * This is a brief description of the method.
   * @param base10 an example input parameter
   * @return some useful result
   */
  
  public static int toBinary( String base10){
    int z = 0;
    for(int a = 0; a < base10.length(); a++){
      z += (base10.charAt(base10.length() - a - 1)- '0') * power(10, a);
    }
    int result = 0;
    int d;
    for(int b = 0; power (2, b) <= z ; b++){
      if( z % power (2, b+1) == 0)
        d = 0;
      else
        d = 1;
      z -= d * power(2, b);
      result += d * power(10, b);
    }
    return result;
  }
  
  
  
  public static void main( String[] args)
  {
    Scanner scan = new Scanner( System.in);
    
    // constants
    
    // variables
    
    // program code
    
    //table that shows some power of the numbers between -1 and 10
    for( double a = -1; a <= 10; a++){
      System.out.print( power (a, 1));
      for ( int b = 0; Double.toString(power(a,1)).length() + b < 10; b++)
        System.out.print(" ");
      System.out.print( power (a, 2));
      for ( int b = 0; Double.toString(power(a,2)).length() + b < 10; b++)
        System.out.print(" ");
      System.out.print( power (a, 3));
      for ( int b = 0; Double.toString(power(a,3)).length() + b < 10; b++)
        System.out.print(" ");
      System.out.print( power (a, 4));
      for ( int b = 0; Double.toString(power(a,4)).length() + b < 10; b++)
        System.out.print(" ");
      System.out.println();
    }
    System.out.println();
    
    //table that shows factorials of the numbers between 1 and 15
    for( int a = 1; a <= 15; a++){
      System.out.print( a );
      for ( int b = 0; Integer.toString(a).length() + b < 6; b++)
        System.out.print(" ");
      System.out.print( factorial(a) );
      for ( int b = 0; Integer.toString(factorial(a)).length() + b < 6; b++)
        System.out.print(" ");
      System.out.println();
    }
    System.out.println();
    
    // compute the sum of numbers base2
    System.out.println( " Please enter the numbers you want to sum up.");
    String binary1;
    String binary2;
    int result;
    binary1 = scan.next();
    binary2 = scan.next();
    
    result = toDecimal(binary1) + toDecimal(binary2);
    System.out.println( toBinary(Integer.toString(result)));
    
    
    //reverse the sentence word by word.
    System.out.println( " Please enter the sentence you want to reverse. ");
    scan.nextLine();
    String text = scan.nextLine();
    String sentence [] = text.split(" ");
    for (int a = 0; a < sentence.length; a++){
      System.out.print( reverse( sentence [a]) + " ");
    }
    System.out.println();
    
    //computes the sin
    System.out.println("Please enter the degree");    
    double x;
    x = scan.nextDouble();
    x = Math.toRadians(x);
    for (int a = 0; a <= 10; a++){
      double taylorResult = 0;
      for(int n = 0; n <= a; n++){
        taylorResult += (power(-1, n) * power( x, 2*n + 1) )/ factorial(2*n + 1) ;
      }
      System.out.println( a + ",   " + taylorResult );
    } 
    System.out.println(); 
    // computes sin in different way
    double taylorResult2 = 0;
    for (int n = 0; n <= 10; n++){
      taylorResult2 += (power(-1, n) * power( x, 2*n + 1) )/ factorial(2*n + 1) ;
      System.out.println( n + ",   " + taylorResult2);
      
    }
  }   
}


