import java.util.ArrayList;

/**
 * __Lab09b - DiceChart___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/12/2017__
 */ 
public class DiceChart
{
   //static variables
   static ArrayList<Integer> list;
   static int starValue;
   
   //methods
   public static int frequency() {
      return starValue;
   }
   
   public static void main( String[] args)
   {
      
      // constant
      final int TIMES_ROLL = 1000;
      
      // variables
      int max;
      Dice dice;
      int diceTotal;
      
      // program code
      System.out.println( "Start...");      
      list = new ArrayList<Integer>();
      dice = new Dice();
      
      //creating a list with eleven value
      for (int i = 0; i<11 ; i++) {
         list.add(0);  
      }
      //filling the list with times value of dice totals
      for (int i = 0; i < TIMES_ROLL ; i++) {
         dice.roll();
         diceTotal = dice.getDiceTotal();
         list.set(diceTotal-2, list.get(diceTotal-2)+1);         
      }
      //finfing the maximum value
      max = 0;
      for (int elem : list) {
         if ( elem > max)
            max = elem;
      }
      //creating chart
      starValue = (int)((max + 9) / 10);
      for (int line = 0; line < 10; line++) {
         for ( int c = 0; c < 11; c++) {
            if (list.get(c) >= (10 - line) * starValue)
               System.out.print("*");
            else
               System.out.print(" ");
            
         }
         System.out.println();
      }
      
      System.out.println( list );
      System.out.println( "Maximum repeat number is " + max );
      System.out.println( "Each star symbolize " + frequency() + " times" );
   }
   
}

