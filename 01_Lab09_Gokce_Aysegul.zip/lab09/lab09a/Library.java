import java.util.ArrayList;
/**
 * A simple Java class!
 */
public class Library
{
   // properties
   private ArrayList<LibraryBook> list;
   
   // constructors
   /**
    * Constructs a library to an empty one
    */
   
   public Library()
   {
     list = new ArrayList<LibraryBook>();
   }
   
   
   // methods
   /**
    * A method to check if library is empty 
    */
   
   public boolean isEmpty()
   {
      return list.size() == 0 ;
   }
   
   // methods
   /**
    * A method to return a string 
    */
   
   public String toString()
   {
      if (list.size() == 0){
         return "It is empty";      
      }
      else {
         String result = "";
         for (LibraryBook book : list)
            result += book + "\n";
         return result;
      }
   }
   
   // methods
   /**
    * A method to return a string 
    */
   
   public void add(String title, String author)
   { 
      LibraryBook book = new LibraryBook(title, author);
      list.add(book);
   }
   
   
   // methods
   /**
    * A method to return a string 
    */
   
   public void remove(LibraryBook book)
   { 
      int identifier = -1;
      for ( int n = 0; n < list.size(); n++){
         if ( list.get(n) == book){
            identifier = n;
         }
      }
      if (identifier >= 0)
         list.remove(identifier);
   }
   
   public LibraryBook findByTitle( String title ) {
      for ( int n = 0; n < list.size(); n++) {
         if ( list.get(n).getTitle().equals(title)) {
            return list.get(n);
         }
      }
      return null;
      
      
   }
   
}